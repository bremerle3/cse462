// ftdiMultithreaded.c
// Jeremy Tang
// 23 April 2015
// Continuously reads data from FTDI and pipe buffer to output.

#include <windows.h>
#include <stdio.h>
#include "FTD2XX.h"
// #include "C:\FTDI\FTD2XX.h"
#include <time.h>

#define TIME_TO_RUN_MSEC 10000
#define CHUNK_SIZE 65536
//#define CHUNK_SIZE 262144
//#define CHUNK_SIZE 253792
//#define CHUNK_SIZE 63448
//#define CHUNK_SIZE 4096
#define BUF_LENGTH 128

int main (int argc, char* argv[]); // main thread
void dataReadProc(void); // ftdi read thread
void dataOutProc(void); // disk write thread

// thread handles
HANDLE hDataReadThread;
HANDLE hDataOutThread;

// multithreading handles
HANDLE hFtdiMutex; // only one thread can read ftdi at a time
HANDLE hWriteBufMutex; // only one thread can write to buffer at a time
int numChunks;		// number of 2KB chunks in the buffer
HANDLE hNumChunksMutex; 

// data buffer
char *dataBuf;
int *lengthBuf;
int readIndex;
int writeIndex;

// timing
clock_t start, diff;
int msec;

// FTDI handles
FT_HANDLE ftHandle; // valid handle returned from FT_OpenEx
FT_DEVICE ftDevice;
DWORD deviceID;
char SerialNumber[16];
char Description[64];

// pipe handles
HANDLE pipe;

// other instance vars
char key;
UCHAR txBuffer[2048]; // transmit buffer
UCHAR rxBuffer[1024 * 64]; // received buffer
DWORD RxBytes, TxBytes; // number of bytes in receive queue, transmit queue
DWORD EventDWord; // current event status
FILE *outFile; // output file
int bytesWritten, bytesReceived; // number of bytes written, received
int totalBytesReceived;
int sz;
FT_STATUS ftStatus;

// modes
int enablePipeOut;
int enableFileOut;
int enableTimer;
int enableByte;
int enableGUI;

// FTDI get device
BOOL getDevice(void)
{
	FT_STATUS ftStatus;
	DWORD numDevs = 0;
	FT_DEVICE_LIST_INFO_NODE *devInfo;
	int i;
	ftStatus = FT_CreateDeviceInfoList(&numDevs);
	if (numDevs > 0) {
		// allocate storage for list based on numDevs
		devInfo = (FT_DEVICE_LIST_INFO_NODE*)malloc(sizeof(FT_DEVICE_LIST_INFO_NODE)*numDevs);
		ftStatus = FT_GetDeviceInfoList(devInfo, &numDevs);
		if (ftStatus == FT_OK) {
			/*
			for (i = 0; i < numDevs; i++) {
				printf("Dev %d:\n", i);
				printf(" Flags=0x%x\n", devInfo[i].Flags);
				printf(" Type=0x%x\n", devInfo[i].Type);
				printf(" ID=0x%x\n", devInfo[i].ID);
				printf(" LocId=0x%x\n", devInfo[i].LocId);
				printf(" SerialNumber=%s\n", devInfo[i].SerialNumber);
				printf(" Description=%s\n", devInfo[i].Description);
				printf(" ftHandle=0x%x\n", devInfo[i].ftHandle);
			}
			*/
		}
	}
	ftStatus = FT_OpenEx("FT2232H MiniModule A", FT_OPEN_BY_DESCRIPTION, &ftHandle);
	if (ftStatus != FT_OK) {
		printf("Failed to open device.\n");
		return FALSE;
	}
	ftStatus = FT_SetBitMode(ftHandle, 0xff, 0x00); // reset
	Sleep(10);
	ftStatus = FT_SetBitMode(ftHandle, 0x00, 0x40);
	if (ftStatus != FT_OK) {
		printf("Failed to set Bit Mode.\n");
		return FALSE;
	}
	ftStatus = FT_SetTimeouts(ftHandle, 500, 500);
	if (ftStatus != FT_OK) {
		printf("Failed to set timeouts.\n");
		return FALSE;
	}
	ftStatus = FT_SetUSBParameters(ftHandle, 64 * 1024, 512);
	if (ftStatus != FT_OK) {
		printf("Failed to set USB parameters.\n");
		return FALSE;
	}
	ftStatus = FT_SetLatencyTimer(ftHandle, 100);
	//ftStatus = FT_SetLatencyTimer(ftHandle, 2);
	if (ftStatus != FT_OK) {
		printf("Failed to set latency timer.\n");
		return FALSE;
	}
	ftStatus = FT_SetFlowControl(ftHandle, FT_FLOW_RTS_CTS, 0, 0);
	//ftStatus = FT_SetFlowControl(ftHandle, FT_FLOW_NONE, 0, 0);
	if (ftStatus != FT_OK) {
		printf("Failed to set flow control.\n");
		return FALSE;
	}
	//purging buffers.
	ftStatus = FT_Purge(ftHandle, FT_PURGE_RX | FT_PURGE_TX);
	if (ftStatus != FT_OK) {
		printf("TX and RX Buffer Purges UNsuccessful\n");
	}
	// deviceID contains encoded device ID
	// SerialNumber, Description contain 0-terminated strings
	ftStatus = FT_GetDeviceInfo(
		ftHandle,
		&ftDevice,
		&deviceID,
		SerialNumber,
		Description,
		NULL
		);
	if (ftStatus == FT_OK) {
		return TRUE;
	}
	else {
		return FALSE;
	}
}

void dataReadProc() {
	WaitForSingleObject(hDataReadThread, INFINITE);
	do {
		// hang if buffer is full
		while (numChunks >= BUF_LENGTH) {
			printf("%6d: Buffer full! WriteIndex=%d, ReadIndex=%d\n", msec, writeIndex, readIndex);
		}
		// read data from FTDI
		ftStatus = FT_Read(ftHandle, &(dataBuf[writeIndex*CHUNK_SIZE]), CHUNK_SIZE, &bytesReceived);
		if (ftStatus == FT_OK) {
			// write data to buffer
			lengthBuf[writeIndex] = bytesReceived;
			writeIndex++;
			if (writeIndex >= BUF_LENGTH) {
				writeIndex = 0;
			}
			// increment number of chunks in buffer
			WaitForSingleObject(hNumChunksMutex, INFINITE);
			numChunks++;
			ReleaseMutex(hNumChunksMutex);
		}
		else {
			printf("%6d: Could not read byte!\n", msec);
		}
	} while (msec < TIME_TO_RUN_MSEC);
	ReleaseMutex(hDataReadThread);
	printf("Read thread done\n");
}

void dataOutProc() {
	int bytesPiped;
	WaitForSingleObject(hDataOutThread, INFINITE);
	do {
		// wait for a data chunk to be in the buffer
		while (numChunks <= 0) {
		}
		if (lengthBuf[readIndex] > 0) {
			// do something with data
			if (enableFileOut) {
				fwrite(&(dataBuf[readIndex*CHUNK_SIZE]), sizeof(char), lengthBuf[readIndex], outFile);
			}
			if (enablePipeOut) {
				WriteFile(pipe, &(dataBuf[readIndex*CHUNK_SIZE]), lengthBuf[readIndex], &bytesPiped, NULL);
			}
			totalBytesReceived += lengthBuf[readIndex];
		} else {
			printf("%5d: Zero bytes read!\n", msec);
		}
		// increment read pointer
		readIndex++;
		if (readIndex >= BUF_LENGTH) {
			readIndex = 0;
		}
		// decrement number of chunks in buffer
		WaitForSingleObject(hNumChunksMutex, INFINITE);
		numChunks--;
		ReleaseMutex(hNumChunksMutex);
	} while (msec < TIME_TO_RUN_MSEC);
	ReleaseMutex(hDataOutThread);
	printf("Write thread done\n");
}

int main(int argc, char* argv[])
{	
	// text file containing the java directory
	FILE *javaConfig;
	char javaPath[1024];
	char javaLauncher[1024];
	
	// user input variables
	char key = 0;
	
	txBuffer[0] = 0;
	
	// get device
	printf("Getting Device Status...\n");
	if (!getDevice()) {
		printf("Error getting device status.\n");
		scanf("%c", &key);
		return -1;
	}
	//printf("\n\nftHandle:\t%d\nftDevice:\t%d\nSN:\t%s\nDesc:\t%s\n\n",
	//	ftHandle, ftDevice, SerialNumber, Description);
	printf("Device ready\n");
	printf("\n");
	sz = sizeof(rxBuffer);
	
	// initialize multithreaded stuff
	hDataReadThread = CreateMutex(NULL, FALSE, NULL);
	hDataOutThread = CreateMutex(NULL, FALSE, NULL);
	hFtdiMutex = CreateMutex(NULL, FALSE, NULL);
	hWriteBufMutex = CreateMutex(NULL, FALSE, NULL);
	numChunks = 0;
	hNumChunksMutex = CreateMutex(NULL, FALSE, NULL);

	// data buffer
	dataBuf = calloc(BUF_LENGTH*CHUNK_SIZE, sizeof(char));
	lengthBuf = calloc(BUF_LENGTH, sizeof(int));
	readIndex = 0;
	writeIndex = 0;
	
	totalBytesReceived = 0;
	
	// open pipe
	pipe = CreateNamedPipe("\\\\.\\pipe\\pipe462", PIPE_ACCESS_OUTBOUND, PIPE_TYPE_BYTE | PIPE_WAIT, 1, 4096, 0, 0, NULL);
	
	// initialize timing
	msec = 0;
	
	// default mode
	enablePipeOut = 1;
	enableFileOut = 0;
	enableTimer = 0;
	enableGUI = 1;
	enableByte = 1;
	
	// print interface
	printf("Jeremy Tang, Leo Bremer\n");
	printf("CSE462M ADC Demo\n");
	printf("23 April 2015\n");
	printf("\n");
	printf("Enter any of the following options:\n");
	printf("\tt: Start reading data from the ADC\n");
	printf("\tx: Quit the application\n");
	printf("\th: Display options\n");
	printf("\ta: Display advanced options\n");
	printf("> ");
	while (key != 't') {
		key = getchar();
		switch (key) {
		case 'x':
			return 0;
		case 'h':
			printf("Enter any of the following options:\n");
			printf("\tt: Start reading data from the ADC\n");
			printf("\tx: Quit the application\n");
			printf("\th: Display options\n");
			printf("\ta: Display advanced options\n");
			break;
		case 'a':
			printf("Advanced Options:\n");
			printf("\tf: Toggle file output\n");
			printf("\tp: Toggle pipe output\n");
			printf("\tg: Toggle default Java GUI\n");
			printf("\tb: Toggle the first byte for initializing the ADC\n");
			printf("\tr: Toggle the ten-second timer\n");
			break;
		case 'f':
			enableFileOut = !enableFileOut;
			if (enableFileOut) {
				printf("File Out Enabled\n");
			} else {
				printf("File Out Disabled\n");
			}
			break;
		case 'r':
			enableTimer = !enableTimer;
			if (enableTimer) {
				printf("Timer Enabled\n");
			} else {
				printf("Timer Disabled\n");
			}
			break;
		case 'p':
			enablePipeOut = !enablePipeOut;
			if (enablePipeOut) {
				printf("Pipe Out Enabled\n");
			} else {
				printf("Pipe Out Disabled\n");
			}
			break;
		case 'b':
			enableByte = !enableByte;
			if (enableByte) {
				printf("Byte Write Enabled\n");
			} else {
				printf("Byte Write Disabled\n");
			}
			break;
		case 'g':
			enableGUI = !enableGUI;
			if (enableGUI) {
				printf("GUI Enabled\n");
			} else {
				printf("GUI Disabled\n");
			}
			break;
		case '\n':
			printf("> ");
			break;
		}
	}
	
	// open file if outputting to file
	if (enableFileOut) {
		// open file
		outFile = fopen("ftdiOut.txt", "wb");
		if (outFile == NULL) {
			printf("Error opening file\n");
			exit(1);
		}
	}
	
	// prepare pipe if outputting to file
	if (enablePipeOut) {
		printf("Waiting on pipe client\n");
		if (enableGUI) {
			// construct java path
			javaConfig = fopen("ADCjavapath.txt", "r");
			if (javaConfig == NULL) {
				printf("Error opening ADCjavapath.txt\n");
				exit(1);
			}
			if (fgets(javaPath, 1024, javaConfig) == NULL) {
				printf("Error reading ADCjavapath.txt\n");
				exit(1);
			}
			fclose(javaConfig);
			if (strlen(javaPath) == 0) {
				printf("Error: ADCjavapath.txt is empty. ADCjavapath.txt should contain the full path to java.exe\n");
				exit(1);
			}
			// launch ADCClient.java
			strcpy(javaLauncher, "start \"ADCClient\" /B \"");
			strcat(javaLauncher, javaPath);
			strcat(javaLauncher, "\" ADCClient");
			system(javaLauncher);
		}
		ConnectNamedPipe(pipe, NULL);
	}
	
	// write a byte out to the FTDI to initialize it
	if (enableByte) {
		// write first byte
		ftStatus = FT_Write(ftHandle, txBuffer, 1, &bytesWritten);
		if (ftStatus != FT_OK) {
			printf("Error: could not write byte.\n");
			return -1;
		}
		printf("Wrote byte\n");
	}
	
	printf("Begin read\n");
	
	// start threads
	_beginthread(dataReadProc, 0, NULL);
	_beginthread(dataOutProc, 0, NULL);
	
	printf("\n");
	
	if (enableTimer) {
		// stop after a set amount of time
		start = clock();
		do {
			diff = clock() - start;
			msec = diff * 1000 / CLOCKS_PER_SEC;
		} while (msec < TIME_TO_RUN_MSEC);
		printf("Timer done\n");
	} else {
		// stop when user says so
		printf("Enter 'x' to stop.\n");
		while (key != 'x') {
			key = getchar();
			if (key == '\n') {
				printf("> ");
			}
		}
		msec = TIME_TO_RUN_MSEC;
	}
	
	// wait for threads to complete
	WaitForSingleObject(hDataReadThread, INFINITE);
	WaitForSingleObject(hDataOutThread, INFINITE);
	
	// grab mutexes
	WaitForSingleObject(hFtdiMutex, INFINITE);
	WaitForSingleObject(hWriteBufMutex, INFINITE);
	WaitForSingleObject(hNumChunksMutex, INFINITE);
	
	// shutdown mutexes
	CloseHandle(hDataReadThread);
	CloseHandle(hDataOutThread);
	CloseHandle(hFtdiMutex);
	CloseHandle(hWriteBufMutex);
	CloseHandle(hNumChunksMutex);
	
	printf("Bytes read: %d\n", totalBytesReceived);
	
	// cleanup
	FT_Close(ftHandle);
	CloseHandle(pipe);
	free(dataBuf);
	free(lengthBuf);
	if (enableFileOut) {
		fclose(outFile);
	}
	
	printf("End ADCServer\n");
}