// ftdiMultithreaded.c : Continuously read from FTDI and pipe buffer to output.
//
#include <windows.h>
#include <stdio.h>
#include <time.h>
#include <string.h>

#define TIME_TO_RUN_MSEC 10000
//#define CHUNK_SIZE 50000
#define CHUNK_SIZE 65536
//#define CHUNK_SIZE 262144
//#define CHUNK_SIZE 253792
//#define CHUNK_SIZE 63448
#define BUF_LENGTH 128

int main (int argc, char* argv[]); // main thread
void ftdiReadProc(void); // ftdi read thread
void diskWriteProc(void); // disk write thread

// multithreading handles
HANDLE hFtdiMutex; // only one thread can read ftdi at a time
HANDLE hWriteBufMutex; // only one thread can write to buffer at a time
int numChunks;		// number of 2KB chunks in the buffer
HANDLE hNumChunksMutex; 

// data buffer
char *dataBuf;
int *lengthBuf;
int readIndex;
int writeIndex;

// timing
clock_t start, diff;
int msec;

// pipe handles
HANDLE pipe;

// other instance vars
char key;
UCHAR txBuffer[2048]; // transmit buffer
UCHAR rxBuffer[1024 * 64]; // received buffer
DWORD RxBytes, TxBytes; // number of bytes in receive queue, transmit queue
DWORD EventDWord; // current event status
FILE *outFile; // output file
int bytesWritten, bytesReceived; // number of bytes written, received
int totalBytesReceived;
int sz;

int decrement = 0;

void ftdiReadProc() {
	int currTime;
	int i;
	char b = 0;
	do {
		currTime = msec;
		while (numChunks >= BUF_LENGTH) {
			printf("%6d: Buffer full! WriteIndex=%d, ReadIndex=%d\n", msec, writeIndex, readIndex);
		}
		// "get data"
		for (i=0; i<CHUNK_SIZE; ++i) {
			dataBuf[writeIndex*CHUNK_SIZE+i] = b;
			b++;
		}
		//b = !b;
		lengthBuf[writeIndex] = CHUNK_SIZE;
		writeIndex++;
		if (writeIndex >= BUF_LENGTH) {
			writeIndex = 0;
		}
		WaitForSingleObject(hNumChunksMutex, INFINITE);
		numChunks++;
		ReleaseMutex(hNumChunksMutex);
		while (msec-currTime < 5) {
		}
	} while (msec < TIME_TO_RUN_MSEC);
	printf("Read thread done\n");
}

void diskWriteProc() {
	int bytesPiped;
	do {
		while (numChunks <= 0) {
		}
		if (lengthBuf[readIndex] > 0) {
			//fwrite(&(dataBuf[readIndex*CHUNK_SIZE]), sizeof(char), lengthBuf[readIndex], outFile);
			WriteFile(pipe, &(dataBuf[readIndex*CHUNK_SIZE]), lengthBuf[readIndex], &bytesPiped, NULL);
			totalBytesReceived += lengthBuf[readIndex];
		} else {
			printf("%5d: Zero bytes read!\n", msec);
		}
		readIndex++;
		if (readIndex >= BUF_LENGTH) {
			readIndex = 0;
		}
		WaitForSingleObject(hNumChunksMutex, INFINITE);
		numChunks--;
		ReleaseMutex(hNumChunksMutex);
	} while (msec < TIME_TO_RUN_MSEC);
	printf("Write thread done\n");
}

int main(int argc, char* argv[])
{	
	// text file containing the java directory
	FILE *javaConfig;
	char javaPath[1024];
	char javaLauncher[1024];
	// user input variables
	char key = 0;
	
	txBuffer[0] = 0;
	
	// open file
	outFile = fopen("ftdiOut.txt", "wb");
	if (outFile == NULL) {
		printf("Error opening ftdiOut.txt\n");
		exit(1);
	}
	
	// construct java path
	javaConfig = fopen("ADCjavapath.txt", "r");
	if (javaConfig == NULL) {
		printf("Error opening ADCjavapath.txt\n");
		exit(1);
	}
	if (fgets(javaPath, 1024, javaConfig) == NULL) {
		printf("Error reading ADCjavapath.txt\n");
		exit(1);
	}
	fclose(javaConfig);
	if (strlen(javaPath) == 0) {
		printf("Error: ADCjavapath.txt is empty. ADCjavapath.txt should contain the full path to java.exe\n");
		exit(1);
	}
	strcpy(javaLauncher, "start \"ADCClient\" /B \"");
	strcat(javaLauncher, javaPath);
	strcat(javaLauncher, "\" ADCClient");
	
	// initialize multithreaded stuff
	hFtdiMutex = CreateMutex(NULL, FALSE, NULL);
	hWriteBufMutex = CreateMutex(NULL, FALSE, NULL);
	numChunks = 0;
	hNumChunksMutex = CreateMutex(NULL, FALSE, NULL);

	// 20KB data buffer
	dataBuf = calloc(BUF_LENGTH*CHUNK_SIZE, sizeof(char));
	lengthBuf = calloc(BUF_LENGTH, sizeof(int));
	readIndex = 0;
	writeIndex = 0;
	
	totalBytesReceived = 0;
	
	// open pipe
	pipe = CreateNamedPipe("\\\\.\\pipe\\pipe462", PIPE_ACCESS_OUTBOUND, PIPE_TYPE_BYTE | PIPE_WAIT, 1, 4096, 0, 0, NULL);
	
	// initialize timing
	msec = 0;
	
	/*
	printf("Press t to start, x to quit\n");
	while (key != 't') {
		key = getchar();
		switch (key) {
		case 'x':
			return 0;
		}
	}
	*/
	
	printf("Waiting on pipe client\n");
	system(javaLauncher);
	ConnectNamedPipe(pipe, NULL);
	
	printf("Begin read\n");
	
	// start threads
	_beginthread(ftdiReadProc, 0, NULL);
	_beginthread(diskWriteProc, 0, NULL);
	
	// start timer
	msec = TIME_TO_RUN_MSEC;
	start = clock();
	do {
		diff = clock() - start;
		msec = diff * 1000 / CLOCKS_PER_SEC;
	} while (msec < TIME_TO_RUN_MSEC);
	printf("Timer done\n");
	
	// grab mutexes, shutdown threads
	WaitForSingleObject(hFtdiMutex, INFINITE);
	WaitForSingleObject(hWriteBufMutex, INFINITE);
	WaitForSingleObject(hNumChunksMutex, INFINITE);
	CloseHandle(hFtdiMutex);
	CloseHandle(hWriteBufMutex);
	CloseHandle(hNumChunksMutex);
	
	printf("Bytes read: %d\n", totalBytesReceived);
	
	// cleanup
	CloseHandle(pipe);
	fclose(outFile);
	free(dataBuf);
	free(lengthBuf);
}