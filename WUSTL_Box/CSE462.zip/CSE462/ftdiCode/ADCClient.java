// ADCClient.java
// Jeremy Tang
// 23 April 2015
// Takes in binary data from a pipe and displays as a waveform.

import java.io.*;

import javax.swing.*;

import java.awt.*;
import java.awt.image.*;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.WindowEvent;
import java.util.Arrays;

public class ADCClient extends JPanel {

	private static final long serialVersionUID = 1L;
	
	// graph dimensions
	private final int IMG_WIDTH = 1024;
	private final int IMG_HEIGHT = 256;

	// gui stuff
	private JFrame frame;
	private JLabel lblImage;
	private BufferedImage img;
	
	public ADCClient() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		// make the frame
		frame = new JFrame();
		frame.getContentPane().setPreferredSize(new Dimension(IMG_WIDTH, IMG_HEIGHT));
		frame.pack();
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setTitle("ADCClient");
		
		// make the graph image
		img = new BufferedImage(IMG_WIDTH, IMG_HEIGHT, BufferedImage.TYPE_INT_RGB);
		lblImage = new JLabel(new ImageIcon(img));
		frame.getContentPane().add(lblImage, BorderLayout.NORTH);
	}
	
	public void getData() {
		// data and image buffers
		int bufSize = 65536;
		byte[] oldImage = new byte[IMG_WIDTH];
		byte[] data = new byte[bufSize];
		
		// painting coordinates
		int x, y, oldY;
		
		// loop iterator
		int i;
		
		// config variables
		int interval = 1;
		int paintCounter = 0;
		int PAINT_COUNT = 3;
		
		// data pipe
		FileInputStream pipe;
		
		// output dump file
		FileOutputStream outFile;
		
		// stat counters
		//int readCount = 0;
		//int bytesRead = 0;
		
		// initialize buffers
		Arrays.fill(oldImage, (byte)0);
		Arrays.fill(data, (byte)0);
		
		// amount of data read
		int hasData = 1, readData = 0;
		
		try {
			// Connect to the pipe
			pipe = new FileInputStream("\\\\.\\pipe\\pipe462");
			outFile = new FileOutputStream("ADCout.txt");
			while (hasData > 0) {
				hasData = pipe.read(data);
				if (hasData > 0) {
					readData = hasData;
					// paint a frame after PAINT_COUNT buffer reads.
					if (paintCounter >= PAINT_COUNT) {
						x = 0;
						for (i=0; x<IMG_WIDTH; i+=interval) {
							// erase old pixel
							oldY = 0xFF - (oldImage[x] & 0xFF);
							img.setRGB(x, oldY, 0x000000);
							
							// paint new pixel
							y = 0xFF - (data[i] & 0xFF);
							img.setRGB(x, y, 0x00FF00);
							
							// save pixel coord so it can be erased in the next frame
							oldImage[x] = data[i];
							
							x++;
						}
						lblImage.paintImmediately(0, 0, IMG_WIDTH, IMG_HEIGHT);
						paintCounter = 0;
					} else {
						paintCounter++;
					}
				}
			}
			// dump buffer into file
			outFile.write(data, 0, readData);
			System.out.format("%d bytes dumped to file\n", readData);
			
			//System.out.format("Read %d times\n", readCount);
			//System.out.format("Total bytes read: %d\n", bytesRead);
			pipe.close();
			outFile.close();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("End ADCClient");
	}
	
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ADCClient window = new ADCClient();
					window.frame.setVisible(true);
					window.getData();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
}