import java.io.*;
import java.util.Arrays;

public class pipetest {

	final protected static char[] hexArray = "0123456789ABCDEF".toCharArray();
	
	public static String bytesToHex(byte[] bytes) {
		char[] hexChars = new char[bytes.length * 2];
		for ( int j = 0; j < bytes.length; j++ ) {
			int v = bytes[j] & 0xFF;
			hexChars[j * 2] = hexArray[v >>> 4];
			hexChars[j * 2 + 1] = hexArray[v & 0x0F];
		}
		return new String(hexChars);
	}

	public static void main(String[] args) {
		int bufSize = 65536;
		byte[] data = new byte[bufSize];
		FileInputStream pipe;
		FileOutputStream outFile;
		int readCount = 0;
		int bytesRead = 0;
	
		try {
			// Connect to the pipe
			pipe = new FileInputStream("\\\\.\\pipe\\pipe462");
			outFile = new FileOutputStream("pipeOut.txt");
			int hasData = 1;
			while (hasData > 0) {
				hasData = pipe.read(data);
				if (hasData > 0) {
					bytesRead += hasData;
					readCount++;
					outFile.write(data, 0, hasData);
				}
			}
			System.out.format("Read %d times\n", readCount);
			System.out.format("Total bytes read: %d\n", bytesRead);
			pipe.close();
			outFile.close();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}